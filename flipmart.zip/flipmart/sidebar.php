<div class="col-md-3 sidebar">
            
            <div class="sidebar-module-container">
              <div class="sidebar-filter">
			<?php dynamic_sidebar('left_sidebar'); ?>
              </div>
            </div>
          </div>