jQuery(document).ready(function($){
	
	//console.log('i m reday');
	var ProductfilterProcess = function(formdata, action){
		$.ajax({
			url: SearchObj.ajax_url,
			type: 'POST',
			data: {
			action: action,
			data: formdata,
			security: SearchObj.security
				
			},
			success: function(response){
				$('ul.products').html(response);
			},
			 error: function(){
				 console.log('Some problem');
			 }
			
			
		});
		
		
	};
	
	$(document).on('ProductFilter', function(){
			$('ul.products').html('<div class="filter_loading"> <img src="'+SearchObj.theme_uri+'/images/loading_spinner.gif" alt="" /></div>');
			var selectedCatsarray = [];
			var ii = 0;
			$(".pro_cats_list li .pro_cat").each(function(){
					if($(this).is(':checked')){
						selectedCatsarray[ii] = $(this).val(),
						ii++;
					}
				
				
			});
			if(selectedCatsarray.length == 0){
				var selectedCats = 'empty';
			}else{
				var selectedCats = selectedCatsarray.join(',');
			}
			console.log(selectedCats);
			var formdata = {
				'minprice' : $('#minprice').val(),
				'maxprice'	 : $('#maxprice').val(),
				'is_archive'	 : $('#is_archive').val(),
				'selectedCats'	 : selectedCats,
				
			};	
			ProductfilterProcess(formdata, 'start_ajax_pro_filter');
	
	});
	
	
	
	$( "#slider-range" ).slider({
	  stop: function( event, ui ) {
		  $(document).trigger('ProductFilter');
	  }
	});
	$('.pro_cats_list li .pro_cat').on('click', function(){
	  
		  $(document).trigger('ProductFilter');
	 
	});
	
	
	
	
});