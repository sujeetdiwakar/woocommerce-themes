<?php 


function maxshop_widget_area_for_shop_page() {
    register_sidebar( array(
        'name' => __( 'Shop Page Siderbar', 'maxshop' ),
        'id' => 'shop-page-sidebar',
        'description' => __( 'Widgets in this area will be shown on sho page.', 'maxshop' ),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
		) );
}

