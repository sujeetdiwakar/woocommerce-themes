	<!-- Widget Area -->
<div class="col-md-4 col-sm-4 col-xs-12 widget-area no-right-padding">
	<?php if(is_active_sidebar( 'shop-page-sidebar' )): ?>
		<?php dynamic_sidebar( 'shop-page-sidebar' ); ?>
	<?php endif; ?>
</div><!-- Widget Area /- -->
